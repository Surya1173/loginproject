  if (!sessionStorage.getItem("refreshed")) {
    sessionStorage.setItem("refreshed", "true");
    location.reload();
}//this is the code i get in chatgpt that is use to auto refresh but that is waste 